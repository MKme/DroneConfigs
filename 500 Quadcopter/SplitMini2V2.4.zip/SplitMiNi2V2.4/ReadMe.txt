HOW TO UPDATE?
The classic method (manually copy the firmware file onto the SD card).
Firmware Upgrade
1. After downloading the firmware, unzip the downloaded file, find the Split-M.BRN file and copy it to the root directory of the microSD card. The firmware name should be confirmed as Split-M.BRN.
2. Turn on the RUNCAM Split Mini with the micro SD card inserted. The camera will automatically update the firmware.
3. Orange light blinks slowly while firmware is upgrading.
4. After 1 minute, the camera will automatically shut down,upgrade has completed.
===========================================================================================
Split-Mini2 Firmware V2.4
1.Fixed the bug:The camera does not turn on properly when the camera board is too hot
2.The name of the video file was changed from Video to DCIM.

===========================================================================================
Split-Mini2 Firmware V2.3
1.Fixed some bugs.

===========================================================================================
Split-Mini2 Firmware V2.2
1.Fixed some bugs.
