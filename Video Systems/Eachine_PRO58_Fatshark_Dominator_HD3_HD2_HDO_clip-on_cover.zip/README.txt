                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:3018152
Eachine PRO58 Fatshark Dominator HD3/HD2/HDO clip-on cover by komar007 is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

This is a cover for the Eachine PRO58 diversity module. The module goes into the cover, then the cover into the goggles. It has clips which will prevent it from falling out of your fatsharks while you fly. No tape needed!

I designed this after printing a couple of cases already available. Whether because of module to module differences or just too tight tolerances/imprecision, none of them seemed to fit my goggles well enough.

It took forever to make - almost a week and about 18 prints until it finally fits perfectly, so I'll really appreciate feedback if you decide to print one for yourself.

I designed it for the Dominator HD3s, but it was also reported to fit HDOs (by [FiAsCoTeC](https://www.thingiverse.com/FiAsCoTeC/about)) and HD2s (by [phaseshift](https://www.thingiverse.com/phaseshift/about)) . If you want to remix this to fit other goggles, here's an Onshape link to the model: https://cad.onshape.com/documents/a2967962b5a508897639f347/w/459fd354f5bb73a3797ccf08/e/fb2a5abfa35e43e2f6d2cb4c 
I think this link is view-only. Let me know if you need permissions to copy.

# Print Settings

Rafts: No
Supports: No
Resolution: 0.1 (including 1st layer)
Infill: 100%

Notes: 
Print as provided - front panel down, with a 0.4mm nozzle.
The thin walls are rather fragile, if they break, try increasing temperature to achieve good layer-to-layer adhesion.
Make sure to clean strings and blobs from the inner side of the front panel, so that it can uniformly touch the OLED.

# Post-Printing

## Installation

Carefully insert the module into the cover, folding back the thin walls. Insert at a slight angle, knob-first. When the knob is safe in its slot, carefully push the back of the module down until the SMAs pop into their holes while still folding the walls. The module will slide a little left to right. Make sure the SMAs are centered in the holes.

Insert the module with the cover on by first fitting the cover in the bay and then aligning the PCB pins with the connector in the bay. Push firmly on all 4 corners until it clicks.

If you're still worried the module will fall out while you fly, use double-sided foam tape, like the one provided with the module for extra security. You may need multiple layers of tape, because the module sits at quite a distance from the bottom of the bay.

## Deinstallation

Removing the module requires a bit of force. Connecting an antenna and pulling by the antenna cable is one tested way.