                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3406364
Mavic Air Spare Propeller Box by Alexander108 is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

I often travel with my Mavic Air Drone. And I always have a full set of propellers with me. However I was afraid that they will be deformed in some way when in just the cardboard inside a pouch. So I needed some kind of box to protect the props.

The wall thickness is merely 1mm. It is a bit wobbly but when the cover sits on top it's absolutely OK. I also experienced that the cover sits a bit loose on the box, however it doesn't fall of when turned upside down. So that is OK with me. Did not change the dimensions. The outer dimensions are exactly the inner dimensions of of the cover.

The little pins are made from 2mm CFK rod. I designed the holes to be 1.5mm so you need to drill it up a little. 1.5mm Pins work as well. Glued them in place with CA.

Let me know if you like the design.

# Print Settings

Printer Brand: Prusa
Printer: i3 MK3
Rafts: No
Supports: No
Resolution: 0,2 or 0,15
Infill: n/a
Filament_brand: PRUSA
Filament_color: Black / Grey
Filament_material: PLA